import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Calendar, Clock, MapPin, Plane, CreditCard, Settings, Users, BarChart3, Sparkles, TrendingUp, Award } from 'lucide-react';
import { mockBookings, mockFlights } from '../lib/mockData';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('bookings');

  const userTabs = [
    { id: 'bookings', label: 'My Bookings', icon: <Calendar className="h-5 w-5" />, gradient: 'from-blue-500 to-cyan-500' },
    { id: 'profile', label: 'Profile', icon: <Settings className="h-5 w-5" />, gradient: 'from-purple-500 to-pink-500' },
  ];

  const adminTabs = [
    { id: 'flights', label: 'Manage Flights', icon: <Plane className="h-5 w-5" />, gradient: 'from-blue-500 to-indigo-500' },
    { id: 'bookings', label: 'All Bookings', icon: <Calendar className="h-5 w-5" />, gradient: 'from-green-500 to-teal-500' },
    { id: 'users', label: 'Users', icon: <Users className="h-5 w-5" />, gradient: 'from-purple-500 to-violet-500' },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 className="h-5 w-5" />, gradient: 'from-orange-500 to-red-500' },
  ];

  const tabs = user?.role === 'admin' ? adminTabs : userTabs;

  // Filter bookings for current user if not admin
  const userBookings = user?.role === 'admin' 
    ? mockBookings 
    : mockBookings.filter(booking => booking.user_id === user?.id);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="glass-card rounded-3xl p-8 text-white nested-cards relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10">
          <Sparkles className="h-32 w-32" />
        </div>
        <div className="flex items-center justify-between relative z-10">
          <div>
            <h1 className="text-4xl font-bold mb-3">
              Welcome back, <span className="gradient-text">{user?.full_name}</span>!
            </h1>
            <p className="text-white/80 text-lg">
              {user?.role === 'admin' ? 'Manage your flight operations with ease' : 'Your premium travel dashboard awaits'}
            </p>
          </div>
          <div className="hidden md:block">
            <div className="glass-card rounded-2xl p-6 floating-animation">
              <Plane className="h-16 w-16 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      {user?.role === 'admin' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-card rounded-2xl p-6 hover-lift nested-cards">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 font-medium">Total Flights</p>
                <p className="text-3xl font-bold text-white">{mockFlights.length}</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-400 mr-1" />
                  <span className="text-green-400 text-sm">+12%</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded-xl">
                <Plane className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
          <div className="glass-card rounded-2xl p-6 hover-lift nested-cards">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 font-medium">Total Bookings</p>
                <p className="text-3xl font-bold text-white">{mockBookings.length}</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-400 mr-1" />
                  <span className="text-green-400 text-sm">+8%</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-xl">
                <Calendar className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
          <div className="glass-card rounded-2xl p-6 hover-lift nested-cards">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 font-medium">Active Users</p>
                <p className="text-3xl font-bold text-white">2</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-400 mr-1" />
                  <span className="text-green-400 text-sm">+25%</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-purple-500 to-violet-500 p-3 rounded-xl">
                <Users className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
          <div className="glass-card rounded-2xl p-6 hover-lift nested-cards">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 font-medium">Revenue</p>
                <p className="text-3xl font-bold text-white">
                  ${mockBookings.reduce((sum, booking) => sum + booking.total_amount, 0).toLocaleString()}
                </p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-400 mr-1" />
                  <span className="text-green-400 text-sm">+15%</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-orange-500 to-red-500 p-3 rounded-xl">
                <CreditCard className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-card rounded-2xl p-6 hover-lift nested-cards">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 font-medium">Total Bookings</p>
                <p className="text-3xl font-bold text-white">{userBookings.length}</p>
                <div className="flex items-center mt-2">
                  <Award className="h-4 w-4 text-yellow-400 mr-1" />
                  <span className="text-yellow-400 text-sm">Premium</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded-xl">
                <Calendar className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
          <div className="glass-card rounded-2xl p-6 hover-lift nested-cards">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 font-medium">Upcoming Trips</p>
                <p className="text-3xl font-bold text-white">
                  {userBookings.filter(b => b.status === 'confirmed').length}
                </p>
                <div className="flex items-center mt-2">
                  <Sparkles className="h-4 w-4 text-purple-400 mr-1" />
                  <span className="text-purple-400 text-sm">Confirmed</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-xl">
                <Plane className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
          <div className="glass-card rounded-2xl p-6 hover-lift nested-cards">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 font-medium">Total Spent</p>
                <p className="text-3xl font-bold text-white">
                  ${userBookings.reduce((sum, booking) => sum + booking.total_amount, 0).toLocaleString()}
                </p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-400 mr-1" />
                  <span className="text-green-400 text-sm">Savings</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-xl">
                <CreditCard className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="glass-card rounded-3xl shadow-lg nested-cards">
        <div className="border-b border-white/20">
          <nav className="flex space-x-8 px-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-3 py-6 px-2 border-b-2 font-semibold text-sm transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'border-purple-400 text-white'
                    : 'border-transparent text-white/60 hover:text-white/80 hover:border-white/30'
                }`}
              >
                <div className={`p-2 rounded-lg ${activeTab === tab.id ? `bg-gradient-to-r ${tab.gradient}` : 'bg-white/10'}`}>
                  {tab.icon}
                </div>
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-8">
          {activeTab === 'bookings' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-white">
                  {user?.role === 'admin' ? 'All Bookings' : 'My Bookings'}
                </h3>
                <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl hover:scale-105 transition-all duration-300 font-semibold ripple-effect">
                  {user?.role === 'admin' ? 'Export Data' : 'View All'}
                </button>
              </div>

              <div className="space-y-4">
                {userBookings.length > 0 ? userBookings.map((booking) => (
                  <div
                    key={booking.id}
                    className="glass-card rounded-2xl p-6 hover-lift"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded-xl">
                          <Plane className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <p className="font-semibold text-white text-lg">
                            {booking.flight?.flight_number || 'N/A'}
                          </p>
                          <p className="text-white/70 flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {booking.flight?.origin} → {booking.flight?.destination}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-white text-xl">${booking.total_amount}</p>
                        <div className="flex items-center text-sm text-white/70">
                          <Clock className="h-4 w-4 mr-1" />
                          {formatDate(booking.booking_date)}
                        </div>
                      </div>
                      <div>
                        <span
                          className={`px-4 py-2 text-sm rounded-full font-medium ${
                            booking.status === 'confirmed'
                              ? 'bg-green-500/20 text-green-300 border border-green-500/30'
                              : booking.status === 'pending'
                              ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30'
                              : 'bg-red-500/20 text-red-300 border border-red-500/30'
                          }`}
                        >
                          {booking.status}
                        </span>
                      </div>
                    </div>
                  </div>
                )) : (
                  <div className="text-center py-16 text-white/60">
                    <Calendar className="h-16 w-16 mx-auto mb-4 text-white/30" />
                    <p className="text-xl">No bookings found</p>
                    <p className="text-white/40 mt-2">Start your journey by booking your first flight</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="space-y-8">
              <h3 className="text-2xl font-bold text-white">Profile Settings</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-white/90">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={user?.full_name || ''}
                    readOnly
                    className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white backdrop-blur-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-white/90">
                    Email
                  </label>
                  <input
                    type="email"
                    value={user?.email || ''}
                    readOnly
                    className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white backdrop-blur-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-white/90">
                    Username
                  </label>
                  <input
                    type="text"
                    value={user?.username || ''}
                    readOnly
                    className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white backdrop-blur-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-white/90">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={user?.phone || ''}
                    readOnly
                    className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white backdrop-blur-sm"
                  />
                </div>
              </div>
              <div className="glass-card rounded-2xl p-6">
                <p className="text-white/80">
                  <Sparkles className="h-5 w-5 inline mr-2 text-yellow-400" />
                  Profile editing is disabled in demo mode. In a full application, you would be able to update your profile information here.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'flights' && user?.role === 'admin' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-white">Manage Flights</h3>
                <button className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-3 rounded-xl hover:scale-105 transition-all duration-300 font-semibold ripple-effect">
                  Add New Flight
                </button>
              </div>
              
              <div className="space-y-4">
                {mockFlights.map((flight) => (
                  <div key={flight.id} className="glass-card rounded-2xl p-6 hover-lift">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-3 rounded-xl">
                          <Plane className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <p className="font-semibold text-white text-lg">{flight.flight_number}</p>
                          <p className="text-white/70">{flight.airline}</p>
                          <p className="text-white/70">
                            {flight.origin} → {flight.destination}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-white text-xl">${flight.price}</p>
                        <p className="text-white/70">
                          {flight.available_seats}/{flight.total_seats} seats
                        </p>
                      </div>
                      <div className="flex space-x-3">
                        <button className="px-4 py-2 bg-blue-500/20 text-blue-300 rounded-lg hover:bg-blue-500/30 transition-colors border border-blue-500/30">
                          Edit
                        </button>
                        <button className="px-4 py-2 bg-red-500/20 text-red-300 rounded-lg hover:bg-red-500/30 transition-colors border border-red-500/30">
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'users' && user?.role === 'admin' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white">User Management</h3>
              <div className="text-center py-16 text-white/60">
                <Users className="h-16 w-16 mx-auto mb-4 text-white/30" />
                <p className="text-xl">User management interface</p>
                <p className="text-white/40 mt-2">Advanced user controls will be available here</p>
              </div>
            </div>
          )}

          {activeTab === 'analytics' && user?.role === 'admin' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white">Analytics Dashboard</h3>
              <div className="text-center py-16 text-white/60">
                <BarChart3 className="h-16 w-16 mx-auto mb-4 text-white/30" />
                <p className="text-xl">Analytics dashboard</p>
                <p className="text-white/40 mt-2">Comprehensive analytics and insights coming soon</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;