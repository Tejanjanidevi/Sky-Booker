import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plane, MapPin, Clock, Users, CreditCard, CheckCircle, Sparkles, Shield, Star } from 'lucide-react';
import { Flight } from '../types';
import { mockBookings } from '../lib/mockData';
import { useAuth } from '../context/AuthContext';

const Booking: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { flight, passengers } = location.state as { flight: Flight; passengers: number };
  
  const [step, setStep] = useState(1);
  const [bookingData, setBookingData] = useState({
    passenger_name: user?.full_name || '',
    passenger_email: user?.email || '',
    passenger_phone: user?.phone || '',
    seat_preference: 'window',
    meal_preference: 'regular',
  });
  const [loading, setLoading] = useState(false);
  const [bookingId, setBookingId] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate booking process
    setTimeout(() => {
      const newBookingId = 'SKY' + Math.random().toString(36).substr(2, 9).toUpperCase();
      setBookingId(newBookingId);
      
      // Add booking to mock data
      const newBooking = {
        id: Date.now().toString(),
        user_id: user?.id || '1',
        flight_id: flight.id,
        passenger_name: bookingData.passenger_name,
        passenger_email: bookingData.passenger_email,
        passenger_phone: bookingData.passenger_phone,
        seat_number: Math.floor(Math.random() * 30) + 1 + ['A', 'B', 'C', 'D', 'E', 'F'][Math.floor(Math.random() * 6)],
        booking_date: new Date().toISOString(),
        status: 'confirmed' as const,
        total_amount: totalAmount,
        flight: flight
      };
      
      mockBookings.push(newBooking);
      
      setLoading(false);
      setStep(3);
    }, 2000);
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const totalAmount = flight.price * passengers;

  if (step === 3) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="glass-card rounded-3xl p-12 text-center nested-cards">
          <div className="mb-8">
            <div className="relative inline-block">
              <CheckCircle className="h-20 w-20 text-green-400 mx-auto mb-6 floating-animation" />
              <div className="absolute -top-2 -right-2">
                <Sparkles className="h-8 w-8 text-yellow-400 animate-pulse" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">
              Booking <span className="gradient-text">Confirmed!</span>
            </h1>
            <p className="text-white/80 text-lg">
              Your premium flight experience awaits. Confirmation details have been sent to your email.
            </p>
          </div>

          <div className="glass-card rounded-2xl p-8 mb-8">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center justify-center">
              <Star className="h-5 w-5 mr-2 text-yellow-400" />
              Booking Details
            </h3>
            <div className="space-y-4 text-white/80">
              <div className="flex justify-between items-center">
                <span className="font-medium">Booking ID:</span>
                <span className="text-white font-bold">{bookingId}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-medium">Flight:</span>
                <span className="text-white font-bold">{flight.flight_number}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-medium">Passenger:</span>
                <span className="text-white font-bold">{bookingData.passenger_name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-medium">Total Amount:</span>
                <span className="text-white font-bold text-xl">${totalAmount}</span>
              </div>
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              onClick={() => navigate('/dashboard')}
              className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-4 px-6 rounded-xl hover:scale-105 transition-all duration-300 font-semibold ripple-effect"
            >
              View My Bookings
            </button>
            <button
              onClick={() => navigate('/')}
              className="flex-1 glass-card text-white py-4 px-6 rounded-xl hover:scale-105 transition-all duration-300 font-semibold"
            >
              Book Another Flight
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={() => navigate(-1)}
          className="p-3 glass-card rounded-xl text-white/80 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-6 w-6" />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-white">Complete Your <span className="gradient-text">Booking</span></h1>
          <p className="text-white/70">Secure your premium flight experience</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Booking Form */}
        <div className="lg:col-span-2">
          <div className="glass-card rounded-3xl p-8 nested-cards">
            {/* Progress Steps */}
            <div className="flex items-center justify-between mb-10">
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold ${
                  step >= 1 ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'bg-white/20 text-white/60'
                }`}>
                  1
                </div>
                <span className={`font-semibold ${
                  step >= 1 ? 'text-white' : 'text-white/60'
                }`}>
                  Passenger Details
                </span>
              </div>
              <div className="flex-1 h-1 bg-white/20 mx-6 rounded-full">
                <div className={`h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-500 ${
                  step >= 2 ? 'w-full' : 'w-0'
                }`}></div>
              </div>
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold ${
                  step >= 2 ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'bg-white/20 text-white/60'
                }`}>
                  2
                </div>
                <span className={`font-semibold ${
                  step >= 2 ? 'text-white' : 'text-white/60'
                }`}>
                  Payment
                </span>
              </div>
            </div>

            {step === 1 && (
              <form onSubmit={(e) => { e.preventDefault(); setStep(2); }} className="space-y-6">
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-white/90">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={bookingData.passenger_name}
                    onChange={(e) => setBookingData({ ...bookingData, passenger_name: e.target.value })}
                    className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                    placeholder="Enter passenger's full name"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-white/90">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={bookingData.passenger_email}
                      onChange={(e) => setBookingData({ ...bookingData, passenger_email: e.target.value })}
                      className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                      placeholder="email@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-white/90">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={bookingData.passenger_phone}
                      onChange={(e) => setBookingData({ ...bookingData, passenger_phone: e.target.value })}
                      className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-white/90">
                      Seat Preference
                    </label>
                    <select
                      value={bookingData.seat_preference}
                      onChange={(e) => setBookingData({ ...bookingData, seat_preference: e.target.value })}
                      className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                    >
                      <option value="window" className="bg-gray-800">Window</option>
                      <option value="aisle" className="bg-gray-800">Aisle</option>
                      <option value="middle" className="bg-gray-800">Middle</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-white/90">
                      Meal Preference
                    </label>
                    <select
                      value={bookingData.meal_preference}
                      onChange={(e) => setBookingData({ ...bookingData, meal_preference: e.target.value })}
                      className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                    >
                      <option value="regular" className="bg-gray-800">Regular</option>
                      <option value="vegetarian" className="bg-gray-800">Vegetarian</option>
                      <option value="vegan" className="bg-gray-800">Vegan</option>
                      <option value="kosher" className="bg-gray-800">Kosher</option>
                      <option value="halal" className="bg-gray-800">Halal</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 text-white py-4 px-6 rounded-xl hover:scale-105 transition-all duration-300 font-semibold ripple-effect"
                >
                  Continue to Payment
                </button>
              </form>
            )}

            {step === 2 && (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="flex items-center space-x-3 mb-8">
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-xl">
                    <CreditCard className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-white">Secure Payment</h3>
                  <Shield className="h-6 w-6 text-green-400" />
                </div>

                <div className="glass-card rounded-2xl p-6 mb-8">
                  <p className="text-white/80 flex items-center">
                    <Sparkles className="h-5 w-5 mr-2 text-yellow-400" />
                    <strong>Demo Mode:</strong> This is a demonstration. No actual payment will be processed.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-white/90">
                    Card Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="1234 5678 9012 3456"
                    defaultValue="4111 1111 1111 1111"
                    className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-white/90">
                      Expiry Date
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="MM/YY"
                      defaultValue="12/25"
                      className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-white/90">
                      CVV
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="123"
                      defaultValue="123"
                      className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-white/90">
                    Cardholder Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="John Doe"
                    value={bookingData.passenger_name}
                    onChange={(e) => setBookingData({ ...bookingData, passenger_name: e.target.value })}
                    className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                  />
                </div>

                <div className="flex space-x-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 glass-card text-white py-4 px-6 rounded-xl hover:scale-105 transition-all duration-300 font-semibold"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 text-white py-4 px-6 rounded-xl hover:scale-105 transition-all duration-300 font-semibold disabled:opacity-50 ripple-effect"
                  >
                    {loading ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        <span>Processing...</span>
                      </div>
                    ) : (
                      'Complete Booking'
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Booking Summary */}
        <div className="lg:col-span-1">
          <div className="glass-card rounded-3xl p-8 sticky top-8 nested-cards">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Sparkles className="h-6 w-6 mr-2 text-yellow-400" />
              Booking Summary
            </h3>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded-xl">
                  <Plane className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="font-bold text-white text-lg">{flight.flight_number}</p>
                  <p className="text-white/70">{flight.airline}</p>
                </div>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-white/70">Date</span>
                  <span className="text-white font-medium">{formatDate(flight.departure_time)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/70">Departure</span>
                  <span className="text-white font-medium">{formatTime(flight.departure_time)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/70">Arrival</span>
                  <span className="text-white font-medium">{formatTime(flight.arrival_time)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/70">Route</span>
                  <span className="text-white font-medium">{flight.origin} → {flight.destination}</span>
                </div>
              </div>
            </div>

            <div className="border-t border-white/20 pt-6 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">Flight Price</span>
                <span className="text-white">${flight.price}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">Passengers</span>
                <span className="text-white">{passengers}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">Taxes & Fees</span>
                <span className="text-white">$45</span>
              </div>
              <div className="border-t border-white/20 pt-3">
                <div className="flex items-center justify-between text-xl font-bold">
                  <span className="text-white">Total</span>
                  <span className="gradient-text">${totalAmount + 45}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 glass-card rounded-2xl p-4">
              <div className="flex items-center text-sm text-white/80">
                <Shield className="h-4 w-4 mr-2 text-green-400" />
                <span>Secure payment protected by 256-bit SSL encryption</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Booking;