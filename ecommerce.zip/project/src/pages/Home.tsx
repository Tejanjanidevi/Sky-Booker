import React, { useState } from 'react';
import { Search, MapPin, Calendar, Users, ArrowRight, Plane, Shield, Clock, Star, Sparkles, Globe, Award, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Home: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchData, setSearchData] = useState({
    origin: '',
    destination: '',
    departure_date: '',
    passengers: 1,
  });

  const handleSearch = () => {
    if (searchData.origin && searchData.destination && searchData.departure_date) {
      if (!user) {
        navigate('/login');
        return;
      }
      navigate('/flights', { state: searchData });
    }
  };

  const features = [
    {
      icon: <Globe className="h-10 w-10" />,
      title: "Global Network",
      description: "Access to 500+ airlines across 200+ countries worldwide",
      gradient: "from-blue-500 to-cyan-500",
      delay: "delay-100"
    },
    {
      icon: <Shield className="h-10 w-10" />,
      title: "Secure Booking",
      description: "Military-grade encryption for all your transactions",
      gradient: "from-green-500 to-emerald-500",
      delay: "delay-200"
    },
    {
      icon: <Clock className="h-10 w-10" />,
      title: "24/7 Support",
      description: "Round-the-clock premium customer assistance",
      gradient: "from-purple-500 to-violet-500",
      delay: "delay-300"
    },
    {
      icon: <Award className="h-10 w-10" />,
      title: "Best Prices",
      description: "Guaranteed lowest prices with price match promise",
      gradient: "from-orange-500 to-red-500",
      delay: "delay-400"
    }
  ];

  const destinations = [
    { 
      city: 'New York', 
      country: 'USA', 
      image: 'https://images.pexels.com/photos/290386/pexels-photo-290386.jpeg?auto=compress&cs=tinysrgb&w=800',
      price: 'from $299',
      gradient: 'from-blue-600/80 to-purple-600/80'
    },
    { 
      city: 'London', 
      country: 'UK', 
      image: 'https://images.pexels.com/photos/460672/pexels-photo-460672.jpeg?auto=compress&cs=tinysrgb&w=800',
      price: 'from $399',
      gradient: 'from-red-600/80 to-pink-600/80'
    },
    { 
      city: 'Tokyo', 
      country: 'Japan', 
      image: 'https://images.pexels.com/photos/2506894/pexels-photo-2506894.jpeg?auto=compress&cs=tinysrgb&w=800',
      price: 'from $599',
      gradient: 'from-pink-600/80 to-rose-600/80'
    },
    { 
      city: 'Paris', 
      country: 'France', 
      image: 'https://images.pexels.com/photos/338515/pexels-photo-338515.jpeg?auto=compress&cs=tinysrgb&w=800',
      price: 'from $349',
      gradient: 'from-indigo-600/80 to-blue-600/80'
    },
    { 
      city: 'Dubai', 
      country: 'UAE', 
      image: 'https://images.pexels.com/photos/1707820/pexels-photo-1707820.jpeg?auto=compress&cs=tinysrgb&w=800',
      price: 'from $499',
      gradient: 'from-yellow-600/80 to-orange-600/80'
    },
    { 
      city: 'Sydney', 
      country: 'Australia', 
      image: 'https://images.pexels.com/photos/995765/pexels-photo-995765.jpeg?auto=compress&cs=tinysrgb&w=800',
      price: 'from $799',
      gradient: 'from-green-600/80 to-teal-600/80'
    },
  ];

  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="text-center py-24 relative">
        <div className="absolute inset-0 flex items-center justify-center opacity-10">
          <Plane className="h-96 w-96 text-white floating-animation" />
        </div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="mb-8">
            <div className="inline-flex items-center space-x-2 glass-card px-6 py-3 rounded-full mb-6">
              <Sparkles className="h-5 w-5 text-yellow-400" />
              <span className="text-white font-medium">Premium Flight Experience</span>
              <Heart className="h-5 w-5 text-red-400" />
            </div>
          </div>
          
          <h1 className="text-6xl md:text-8xl font-bold mb-8 leading-tight">
            <span className="gradient-text block">
              Discover Your
            </span>
            <span className="text-white block">
              Next Adventure
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-white/90 mb-16 max-w-3xl mx-auto leading-relaxed">
            Embark on extraordinary journeys with our premium flight booking platform. 
            Compare prices, discover destinations, and create unforgettable memories.
          </p>

          {/* Enhanced Search Card */}
          <div className="glass-card rounded-3xl p-8 max-w-6xl mx-auto nested-cards hover-lift">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
              <div className="space-y-3">
                <label className="text-sm font-semibold text-white/90 flex items-center">
                  <MapPin className="h-4 w-4 mr-2 text-blue-400" />
                  From
                </label>
                <input
                  type="text"
                  placeholder="Origin city"
                  value={searchData.origin}
                  onChange={(e) => setSearchData({ ...searchData, origin: e.target.value })}
                  className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                />
              </div>

              <div className="space-y-3">
                <label className="text-sm font-semibold text-white/90 flex items-center">
                  <MapPin className="h-4 w-4 mr-2 text-pink-400" />
                  To
                </label>
                <input
                  type="text"
                  placeholder="Destination city"
                  value={searchData.destination}
                  onChange={(e) => setSearchData({ ...searchData, destination: e.target.value })}
                  className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                />
              </div>

              <div className="space-y-3">
                <label className="text-sm font-semibold text-white/90 flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-green-400" />
                  Departure
                </label>
                <input
                  type="date"
                  value={searchData.departure_date}
                  onChange={(e) => setSearchData({ ...searchData, departure_date: e.target.value })}
                  className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                />
              </div>

              <div className="space-y-3">
                <label className="text-sm font-semibold text-white/90 flex items-center">
                  <Users className="h-4 w-4 mr-2 text-orange-400" />
                  Passengers
                </label>
                <select
                  value={searchData.passengers}
                  onChange={(e) => setSearchData({ ...searchData, passengers: parseInt(e.target.value) })}
                  className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-white focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
                >
                  {[1, 2, 3, 4, 5, 6].map(num => (
                    <option key={num} value={num} className="bg-gray-800">{num} {num === 1 ? 'Passenger' : 'Passengers'}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <button
                  onClick={handleSearch}
                  className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-white py-4 px-6 rounded-xl hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2 font-semibold shadow-lg hover:shadow-xl ripple-effect"
                >
                  <Search className="h-5 w-5" />
                  <span>Search Flights</span>
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Why Choose <span className="gradient-text">SkyBooker</span>?
            </h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto">
              Experience the future of flight booking with our cutting-edge platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`glass-card rounded-2xl p-8 hover-lift ${feature.delay} nested-cards group`}
              >
                <div className={`bg-gradient-to-r ${feature.gradient} p-4 rounded-2xl mb-6 w-fit group-hover:scale-110 transition-transform duration-300`}>
                  <div className="text-white">{feature.icon}</div>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">
                  {feature.title}
                </h3>
                <p className="text-white/80 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Destinations */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Popular <span className="gradient-text">Destinations</span>
            </h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto">
              Discover the world's most breathtaking destinations with exclusive deals
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.map((destination, index) => (
              <div
                key={index}
                className="relative group cursor-pointer overflow-hidden rounded-3xl hover-lift nested-cards"
              >
                <img
                  src={destination.image}
                  alt={destination.city}
                  className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${destination.gradient} to-transparent`}></div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-1">{destination.city}</h3>
                      <p className="text-white/90 mb-2">{destination.country}</p>
                      <span className="inline-block bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-white text-sm font-medium">
                        {destination.price}
                      </span>
                    </div>
                    <div className="bg-white/20 backdrop-blur-sm p-3 rounded-full group-hover:scale-110 transition-transform duration-300">
                      <ArrowRight className="h-6 w-6 text-white" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;