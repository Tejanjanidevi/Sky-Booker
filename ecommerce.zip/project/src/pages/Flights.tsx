import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search, Filter, Clock, MapPin, Plane, Users, ArrowRight, Sparkles, Star, Zap } from 'lucide-react';
import { Flight, SearchFilters } from '../types';
import { mockFlights } from '../lib/mockData';

const Flights: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [flights, setFlights] = useState<Flight[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<SearchFilters>(
    location.state || {
      origin: '',
      destination: '',
      departure_date: '',
      passengers: 1,
      sort_by: 'price'
    }
  );

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      let filteredFlights = [...mockFlights];
      
      // Filter by origin and destination if provided
      if (filters.origin) {
        filteredFlights = filteredFlights.filter(flight => 
          flight.origin.toLowerCase().includes(filters.origin.toLowerCase())
        );
      }
      
      if (filters.destination) {
        filteredFlights = filteredFlights.filter(flight => 
          flight.destination.toLowerCase().includes(filters.destination.toLowerCase())
        );
      }
      
      // Sort flights
      switch (filters.sort_by) {
        case 'price':
          filteredFlights.sort((a, b) => a.price - b.price);
          break;
        case 'departure':
          filteredFlights.sort((a, b) => new Date(a.departure_time).getTime() - new Date(b.departure_time).getTime());
          break;
        case 'duration':
          filteredFlights.sort((a, b) => {
            const durationA = new Date(a.arrival_time).getTime() - new Date(a.departure_time).getTime();
            const durationB = new Date(b.arrival_time).getTime() - new Date(b.departure_time).getTime();
            return durationA - durationB;
          });
          break;
      }
      
      setFlights(filteredFlights);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, [filters]);

  const handleBookFlight = (flight: Flight) => {
    navigate('/booking', { state: { flight, passengers: filters.passengers } });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDuration = (departure: string, arrival: string) => {
    const dep = new Date(departure);
    const arr = new Date(arrival);
    const diff = arr.getTime() - dep.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="glass-card rounded-2xl p-8">
          <div className="flex flex-col items-center space-y-4">
            <div className="w-16 h-16 border-4 border-purple-400/30 border-t-purple-400 rounded-full animate-spin"></div>
            <p className="text-white font-medium">Searching for the best flights...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Search Header */}
      <div className="glass-card rounded-3xl p-8 nested-cards">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">
              Available <span className="gradient-text">Flights</span>
            </h1>
            <p className="text-white/70">Find your perfect journey</p>
          </div>
          <div className="flex items-center space-x-4">
            <select
              value={filters.sort_by}
              onChange={(e) => setFilters({ ...filters, sort_by: e.target.value as 'price' | 'departure' | 'duration' })}
              className="px-5 py-3 rounded-xl bg-white/10 border border-white/20 text-white focus:ring-2 focus:ring-purple-400 focus:border-transparent backdrop-blur-sm"
            >
              <option value="price" className="bg-gray-800">Sort by Price</option>
              <option value="departure" className="bg-gray-800">Sort by Departure</option>
              <option value="duration" className="bg-gray-800">Sort by Duration</option>
            </select>
            <button className="flex items-center space-x-2 px-5 py-3 text-white/80 hover:text-white transition-colors glass-card rounded-xl">
              <Filter className="h-4 w-4" />
              <span>Filters</span>
            </button>
          </div>
        </div>

        <div className="flex items-center space-x-6 text-sm text-white/70">
          <div className="flex items-center space-x-2 glass-card px-4 py-2 rounded-full">
            <MapPin className="h-4 w-4 text-blue-400" />
            <span>{filters.origin || 'Any'} → {filters.destination || 'Any'}</span>
          </div>
          <div className="flex items-center space-x-2 glass-card px-4 py-2 rounded-full">
            <Clock className="h-4 w-4 text-green-400" />
            <span>{filters.departure_date || 'Any date'}</span>
          </div>
          <div className="flex items-center space-x-2 glass-card px-4 py-2 rounded-full">
            <Users className="h-4 w-4 text-purple-400" />
            <span>{filters.passengers} passenger{filters.passengers > 1 ? 's' : ''}</span>
          </div>
        </div>
      </div>

      {/* Flight Results */}
      <div className="space-y-6">
        {flights.map((flight, index) => (
          <div
            key={flight.id}
            className="glass-card rounded-3xl p-8 hover-lift nested-cards group"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300">
                      <Plane className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white">
                        {flight.flight_number}
                      </h3>
                      <p className="text-white/70 text-lg">{flight.airline}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Star className="h-4 w-4 text-yellow-400" />
                        <span className="text-yellow-400 text-sm font-medium">Premium Service</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-white">
                      ${flight.price}
                    </p>
                    <p className="text-white/70">per person</p>
                    <div className="flex items-center justify-end mt-1">
                      <Zap className="h-4 w-4 text-green-400 mr-1" />
                      <span className="text-green-400 text-sm">Best Deal</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6">
                  <div className="flex items-center space-x-6">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-white">
                        {formatTime(flight.departure_time)}
                      </p>
                      <p className="text-white/70 font-medium">{flight.origin}</p>
                    </div>
                    <div className="flex-1 flex items-center">
                      <div className="w-full border-t-2 border-gradient-to-r from-purple-400 to-pink-400 relative">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-purple-500 to-pink-500 p-2 rounded-full">
                          <ArrowRight className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-white">
                        {formatTime(flight.arrival_time)}
                      </p>
                      <p className="text-white/70 font-medium">{flight.destination}</p>
                    </div>
                  </div>

                  <div className="text-center">
                    <p className="text-xl font-bold text-white">
                      {formatDuration(flight.departure_time, flight.arrival_time)}
                    </p>
                    <p className="text-white/70">Duration</p>
                    <div className="flex items-center justify-center mt-1">
                      <Clock className="h-4 w-4 text-blue-400 mr-1" />
                      <span className="text-blue-400 text-sm">Direct Flight</span>
                    </div>
                  </div>

                  <div className="text-center">
                    <p className="text-xl font-bold text-white">
                      {flight.available_seats}
                    </p>
                    <p className="text-white/70">Seats Available</p>
                    <div className="flex items-center justify-center mt-1">
                      <Sparkles className="h-4 w-4 text-purple-400 mr-1" />
                      <span className="text-purple-400 text-sm">Premium Cabin</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-6 text-sm text-white/70">
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span>{flight.aircraft_type}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                      <span>Economy Class</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                      <span>Free Wi-Fi</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-pink-400 rounded-full"></div>
                      <span>Meals Included</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleBookFlight(flight)}
                    className="bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 text-white px-8 py-4 rounded-xl hover:scale-105 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl ripple-effect"
                  >
                    Select Flight
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {flights.length === 0 && (
        <div className="text-center py-20">
          <div className="glass-card rounded-3xl p-12 max-w-md mx-auto">
            <Plane className="h-20 w-20 mx-auto text-white/30 mb-6" />
            <h3 className="text-2xl font-bold text-white mb-4">
              No flights found
            </h3>
            <p className="text-white/70 mb-6">
              Try adjusting your search criteria or check back later for new flights.
            </p>
            <button 
              onClick={() => navigate('/')}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl hover:scale-105 transition-all duration-300 font-semibold"
            >
              Search Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Flights;