export interface User {
  id: string;
  email: string;
  username: string;
  role: 'user' | 'admin';
  full_name: string;
  phone?: string;
  created_at: string;
}

export interface Flight {
  id: string;
  flight_number: string;
  airline: string;
  origin: string;
  destination: string;
  departure_time: string;
  arrival_time: string;
  price: number;
  available_seats: number;
  total_seats: number;
  aircraft_type: string;
  created_at: string;
}

export interface Booking {
  id: string;
  user_id: string;
  flight_id: string;
  passenger_name: string;
  passenger_email: string;
  passenger_phone: string;
  seat_number?: string;
  booking_date: string;
  status: 'confirmed' | 'cancelled' | 'pending';
  total_amount: number;
  flight?: Flight;
  user?: User;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => void;
  loading: boolean;
}

export interface RegisterData {
  email: string;
  password: string;
  username: string;
  full_name: string;
  phone?: string;
}

export interface SearchFilters {
  origin: string;
  destination: string;
  departure_date: string;
  passengers: number;
  sort_by: 'price' | 'departure' | 'duration';
}