import React, { createContext, useContext, useState } from 'react';
import { User, AuthContextType, RegisterData } from '../types';
import { mockUsers } from '../lib/mockData';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);

  const login = async (email: string, password: string) => {
    setLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check mock credentials
    const foundUser = mockUsers.find(u => u.email === email);
    
    if (!foundUser) {
      setLoading(false);
      throw new Error('Invalid email or password');
    }
    
    // Check password (simplified for demo)
    const validPasswords: { [key: string]: string } = {
      'admin@skybook.com': 'admin123',
      'user@skybook.com': 'user123'
    };
    
    if (validPasswords[email] !== password) {
      setLoading(false);
      throw new Error('Invalid email or password');
    }
    
    setUser(foundUser);
    setLoading(false);
    
    // Store in localStorage for persistence
    localStorage.setItem('user', JSON.stringify(foundUser));
  };

  const register = async (userData: RegisterData) => {
    setLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Check if user already exists
    const existingUser = mockUsers.find(u => u.email === userData.email || u.username === userData.username);
    if (existingUser) {
      setLoading(false);
      throw new Error('User with this email or username already exists');
    }
    
    // Create new user
    const newUser: User = {
      id: Date.now().toString(),
      email: userData.email,
      username: userData.username,
      full_name: userData.full_name,
      phone: userData.phone,
      role: 'user',
      created_at: new Date().toISOString()
    };
    
    mockUsers.push(newUser);
    setUser(newUser);
    setLoading(false);
    
    // Store in localStorage for persistence
    localStorage.setItem('user', JSON.stringify(newUser));
  };

  const logout = async () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  // Check for stored user on mount
  React.useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        localStorage.removeItem('user');
      }
    }
  }, []);

  const value = {
    user,
    login,
    register,
    logout,
    loading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};